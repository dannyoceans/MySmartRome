<?php
/*ci colleghiamo al database(attenti perchè se lavorate in locale 
l'host è 10.0.2.2 e non 127.0.0.1)*/
   $msg = $_GET['msg'];
   $mitt= $_GET['idM'];
   $dest = $_GET['idD'];
   $data= $_GET['data'];

 mysql_connect("localhost","progettomagistrale",""); 
//selezioniamo il db a cui ci vogliamo connettere
mysql_select_db("my_progettomagistrale");

//creamo al query
$sql="INSERT INTO msg (idMitt,idDest,testo,data) VALUES ($mitt,$dest,$msg,$data)";
if(mysql_query($sql)){
    print(("OK"));
} else{
   print("KO");
   
   }
 
// Close connection
mysql_close();
?>