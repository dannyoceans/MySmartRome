<!DOCTYPE html>
<html lang="en">
<head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



<?php

 include 'database.php' ;

 include 'navbar.php' ;
if(isset($_POST['login']))
{
  $user=$_POST['user'];
  $pswd=$_POST['pswd'];
  $data = new MysqlClass();
  $data->connetti();
	echo $data->login($user,$pswd);
  if($data->login($user,$pswd))
  {
   echo"ok";

  }else{ echo"no";}
  


}


include 'form.php' ;

if(isset($_POST['registration']))
{   
    $email=$_POST['email'];
    $pswd=$_POST['pswd'];
    $citta=$_POST['citta'];
    $via==$_POST['via'];
    $civico=$_POST['civico'];
    $data = new MysqlClass();
    $data->connetti();
    $data->query("INSERT INTO `business`(`id`, `email`, `password`, `citta`, `via`, `civico`) VALUES ('','$email','$pswd','$citta','$via','$civico')");
    echo "Grazie per esserti registrato procedi con il login";
   

}
 
 
 ?>

   





</body>
</html>