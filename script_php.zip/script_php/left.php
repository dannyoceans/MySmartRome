<div class="row ">

    <div class="col-md-12">

 

        <img src="logo.png" width='450' height='450'  class="d-inline-block align-top" alt="">

        </div>
         </div>

        