<?php
define('HOST','localhost');
 define('USER','progettomagistrale');
 define('PASS','');
 define('DB','my_progettomagistrale');
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 ?>
 