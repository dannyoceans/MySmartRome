<form class="form-inline navbar-right " style="padding:10px" role="search" method="POST">

  <button type="submit" class="btn btn-primary" name="logout">Logout</button>
</form>


