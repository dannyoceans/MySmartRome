<div class="row ">

    <div class="col-md-12">
    <form class="form-horizontal" method="POST">
  <fieldset>
    <legend>registration MySmartRome Business</legend> 
    <div class="form-group">
   
      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputEmail" placeholder="Email" name="email">
      </div>
    </div>
        <div class="form-group">
   
      <div class="col-lg-10">
        <input type="password" class="form-control" id="inputEmail" placeholder="Password" name="pswd">
      </div>
    </div>
        <div class="form-group">
   
      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputEmail" placeholder="citta" name="citta">
      </div>
    </div>
        <div class="form-group">

      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputEmail" placeholder="via" name="via">
      </div>
    </div>
        <div class="form-group">

      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputcivico" placeholder="civico" name="civico">
      </div>
    </div>
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-4">
        <button type="submit" class="btn btn-primary" name="registration" >Register Now</button>
      </div>
    </div>
  </fieldset>
</form>

</div>
    </div>

